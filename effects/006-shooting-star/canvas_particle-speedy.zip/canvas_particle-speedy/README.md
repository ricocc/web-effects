# [canvas_particle]SPEEDY

A Pen created on CodePen.io. Original URL: [https://codepen.io/ma_suwa/pen/wvGjLyd](https://codepen.io/ma_suwa/pen/wvGjLyd).

